package com.example.formation.miniprojet_dib_jourdan.dataaccess;

/**
 * Created by formation on 25/01/2017.
 */
import android.database.sqlite.SQLiteDatabase;



import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.formation.miniprojet_dib_jourdan.dataobject.Localisation;


public class DataSource {
    //connexion à la base de données


    private SQLiteDatabase db;
    private final DBHelper helper;

    public DataSource(Context context){
        helper = new DBHelper(context);
    }

    public SQLiteDatabase getDB(){

        if (db == null) open ();
        return db;

    }

    public void open() throws SQLException {
        db = helper.getWritableDatabase();

    }

    public void close(){
        helper.close();

    }

    //factory
    public LocalisationDataAccessObject newLocalisationDataAccessObject(){
        return new LocalisationDataAccessObject(this);
    }

}
