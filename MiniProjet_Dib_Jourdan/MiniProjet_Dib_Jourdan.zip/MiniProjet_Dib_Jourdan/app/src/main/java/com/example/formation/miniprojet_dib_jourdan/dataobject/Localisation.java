package com.example.formation.miniprojet_dib_jourdan.dataobject;

/**
 * Created by formation on 25/01/2017.
 */

import android.location.Location;


public class Localisation extends Pojo {

    private Integer id;
    private String name;
    private Double longitude;
    private Double latitude;
    private String image;


    //Getters / setters
    public int getId() {
        return id;
    }

    ;

    public void setNom(Integer id) {
        this.id = id;
    }

    ;

    public String getNom() {
        return name;
    }

    ;

    public void setNom(String nom) {
        this.name = nom;
    }

    ;

    public Double getLongitude() {
        return longitude;
    }

    ;

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    ;

    public Double getLatitude() {
        return latitude;
    }

    ;

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    ;

    public String get_image() {
        return image;
    }

    public void set_image(String str) {
        this.image = str;
    }


    //constructeurs
    public Localisation(int id) {
        super(id);

    }

    ;

    public Localisation(int id, String name, Double longitude, Double latitude,String image) {
        super(id);
        this.id = id;
        this.name = name;
        this.longitude = longitude;
        this.latitude = latitude;
        this.image=image;
    }

    ;




}
