package com.example.formation.miniprojet_dib_jourdan.dataobject;

/**
 * Created by formation on 25/01/2017.
 */
public class Pojo {
    //Atributs
    private int id;

    //Getters / setters
    public int getId(){return id;};
    public void setId(int id) {this.id = id;};

    //constructeur
    public Pojo(int id){
        this.id = id;
    };
}
