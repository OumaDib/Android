package com.example.formation.miniprojet_dib_jourdan.dataaccess;

/**
 * Created by formation on 25/01/2017.
 */
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.location.Location;

import com.example.formation.miniprojet_dib_jourdan.dataobject.Localisation;

import java.util.ArrayList;
import java.util.List;



public class LocalisationDataAccessObject {
    public static final String COL_ID="id";
    public static final String COL_NOM="name";
    public static final String COL_Longitude="longitude";
    public static final String COL_Latitude="latitude";
    public static final String COL_IMAGE="image";
    public static final String TABLE_NAME="Enregistrement";


    private final DataSource datasource;

    //constructor
    public LocalisationDataAccessObject(DataSource datasource){
        this.datasource = datasource;
    }



    public synchronized Localisation insert(Localisation mObjet) {

        //on copie les champs de l'objet dans les colonnes de la table.
        ContentValues values=new ContentValues();

        values.put(COL_NOM, mObjet.getNom());
        values.put(COL_Longitude, mObjet.getLongitude());
        values.put(COL_Latitude, mObjet.getLatitude());
        values.put(COL_IMAGE,mObjet.get_image());


        //insert query
        int id=(int)datasource.getDB().insert(TABLE_NAME,null,values);

        //mise à jour de l'ID dans l'objet
        mObjet.setId(id);

        return mObjet;


    }



    public synchronized Localisation update(Localisation mObjet){

        //on copie les champs de l'objet dans les colonnes de la table.
        ContentValues values=new ContentValues();
        values.put(COL_ID, mObjet.getId());
        values.put(COL_NOM, mObjet.getNom());
        values.put(COL_Longitude, mObjet.getLongitude());
        values.put(COL_Latitude, mObjet.getLatitude());
        values.put(COL_IMAGE, mObjet.get_image());

        //gestion de la clause "WHERE"
        String clause = COL_ID + " = ? ";
        String[] clauseArgs = new String[]{
                String.valueOf(mObjet.getId())
        };

        datasource.getDB().update(TABLE_NAME, values, clause, clauseArgs);

        //mise à jour de l'ID dans l'objet
        return mObjet;


    }


    public synchronized void delete(Localisation mObjet){


        //gestion de la clause "WHERE"
        String clause = COL_ID + " = ? ";
        String[] clauseArgs = new String[]{
                String.valueOf(mObjet.getId())
        };

        datasource.getDB().delete(TABLE_NAME, clause, clauseArgs);

    }


    public Localisation read(Localisation mObjet){


        //columns
        String[] allColumns = new String[]{COL_ID,COL_NOM,COL_Longitude,COL_Latitude,COL_IMAGE};


        //clause
        String clause = COL_ID + " = ? ";
        String[] clauseArgs = new String[]{
                String.valueOf(mObjet.getId())
        };


        //select query
        Cursor cursor = datasource.getDB().query(TABLE_NAME,allColumns, "ID = ?", clauseArgs, null, null,null);

        //read cursor. On copie les valeurs de la table dans l'objet
        cursor.moveToFirst();
        mObjet.setId(cursor.getInt(0));
        mObjet.setNom(cursor.getString(1));
        mObjet.setLongitude(cursor.getDouble(2));
        mObjet.setLatitude(cursor.getDouble(3));
        mObjet.set_image(cursor.getString(4));
        cursor.close();

        return mObjet;


    }

    public List<Localisation> readAll(){


        //columns
        String[] allColumns = new String[]{COL_ID,COL_NOM,COL_Longitude,COL_Latitude,COL_IMAGE};


        //select query
        Cursor cursor = datasource.getDB().query(TABLE_NAME,allColumns, null, null, null, null,null);

        //Iterate on cursor and retrieve result
        List<Localisation> liste_Localisation = new ArrayList<Localisation>();


        cursor.moveToFirst();

        while (!cursor.isAfterLast()){

            liste_Localisation.add(new Localisation(cursor.getInt(0), cursor.getString(1), cursor.getDouble(2), cursor.getDouble(3), cursor.getString(4)));
            cursor.moveToNext();

        }

        cursor.close();

        return liste_Localisation;


    }
}
