package com.example.formation.miniprojet_dib_jourdan.dataaccess;

/**
 * Created by formation on 25/01/2017.
 */

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class DBHelper extends SQLiteOpenHelper {
    //utilisation du modèle de données


    public static final String DB_NAME = "base_de_donnees_localisation.db";
    public static final int DB_VERSION = 1;


    //constructor
    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    public static String getQueryCreate_Enregistrement() {
        return "CREATE TABLE Enregistrement("
                + "id Integer PRIMARY KEY AUTOINCREMENT, "
                + "name Text NOT NULL,"
                + "latitude Float,"
                +"longitude Float,"
                + "image Text"
                + ");"
                ;
    }


    public static String getQueryDrop_Enregistrement() {
        return "DROP TABLE IF EXISTS Enregistrement;";
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        //ceci est automatiquement géré par SQLite
        db.execSQL(getQueryCreate_Enregistrement());


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL(getQueryDrop_Enregistrement());
        db.execSQL(getQueryCreate_Enregistrement());

    }
}



