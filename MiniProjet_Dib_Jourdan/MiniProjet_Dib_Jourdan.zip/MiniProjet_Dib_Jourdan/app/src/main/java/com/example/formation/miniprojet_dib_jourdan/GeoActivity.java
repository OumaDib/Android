package com.example.formation.miniprojet_dib_jourdan;

/**
 * Created by formation on 19/01/2017.
 */
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.media.ExifInterface;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.formation.miniprojet_dib_jourdan.dataaccess.DataSource;
import com.example.formation.miniprojet_dib_jourdan.dataaccess.LocalisationDataAccessObject;
import com.example.formation.miniprojet_dib_jourdan.dataobject.Localisation;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class GeoActivity extends FragmentActivity implements OnMapReadyCallback {

    Button bouton_photo;
    Button bouton_email;


    File mFichier = null;

    Location lastLocation = null;
    Time lastTime = null;
    GoogleMap mMap;
    Marker mMarker;
    boolean isMapReady = false;


    Button bouton_enregistrer;
    DataSource mdatasource = null;
    String texte_name_str = null;
    LocalisationDataAccessObject mLocalisationDataAccessObject=null;
    private Double latitude;
    private Double longitude;

    String mCurrentPhotoPath;







    Camera camera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_geo);



        bouton_photo = (Button) findViewById(R.id.b_picture);

        bouton_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Réagir à un clic
                prendre_photo();
            }
        });

        bouton_email = (Button) findViewById(R.id.b_email);

        bouton_email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                emailIntent.setType("plain/text");
                emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"herve.quinquenel@ign.fr"});
                emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "PROBLEME : " );
                emailIntent.putExtra(android.content.Intent.EXTRA_TEXT,  "Latitude : " + latitude + "\n" + "Longitude : " + longitude);
                //pour ajouter une pièce jointe définie par une URL
                if (mCurrentPhotoPath != null) {
                    emailIntent.putExtra(Intent.EXTRA_STREAM, Uri.parse("file:" + mCurrentPhotoPath));
                }
                startActivity(Intent.createChooser(emailIntent, "Send mail..."));

            }
        });




        // Init the location manager
        LocationManager locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);

        // Init the position eventListener
        try {
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10, 1, locationListener);
            // App is running
            Toast.makeText(GeoActivity.this, "Application lancée...", Toast.LENGTH_SHORT).show();
        }
        catch (SecurityException e) {
            // App does not has required permissions
            Toast.makeText(GeoActivity.this, "L'application n'a pas les autorisations requises...", Toast.LENGTH_LONG).show();
        }

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        ArrayList<LocationProvider> providers = new ArrayList<LocationProvider>();
        ArrayList<String> names = (ArrayList<String>)locationManager.getProviders(true);


        for(String name : names)
            providers.add(locationManager.getProvider(name));


        //instanciation de la base de données SQLite
        mdatasource = new DataSource(GeoActivity.this);
        mLocalisationDataAccessObject = mdatasource.newLocalisationDataAccessObject();
        mdatasource.open();

        //Réinitialisation de la BD
//        List<Localisation> locList = mLocalisationDataAccessObject.readAll();
//        for(Localisation loc : locList){
//            mLocalisationDataAccessObject.delete(loc);
//        }

        //Ecrit_DB();
        bouton_enregistrer=(Button)findViewById(R.id.button_enregistrer);
        bouton_enregistrer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double latitude = lastLocation.getLatitude();
                Double longitude = lastLocation.getLongitude();
                String texte_name_str = "cool";

                //L'identifiant "-1" dit à SQLite de créer un nouvel identifiant en autoincrémentation avec ORMlite. Inutile avec SQlite.
                Localisation mEnregistrement = new Localisation(-1, texte_name_str, longitude, latitude, mCurrentPhotoPath);
                //Stockage des attributs de l'objet dans la base de données
                mLocalisationDataAccessObject.insert(mEnregistrement);
                mapUpdate();

                Toast.makeText(GeoActivity.this, "Données enregistrées dans la BDD", Toast.LENGTH_SHORT).show();
            }

        });





}


    public void prendre_photo() {

        // L'endroit où sera enregistrée la photo
        // Remarquez que mFichier est un attribut de ma classe
        //mFichier = new File(Environment.getExternalStorageDirectory(), "photo.jpg");
        mFichier = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "photo.jpg");
        //mFichier = new File(Environment.getExternalStoragePublicDirectory(DIRECTORY_PICTURES), "photo.jpg");


        // On récupère ensuite l'URI associée au fichier
        Uri fileUri = Uri.fromFile(mFichier);
        mCurrentPhotoPath = fileUri.getPath();

        // Maintenant, on crée l'intent
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Et on déclare qu'on veut que l'image soit enregistrée là où pointe l'URI
        intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);

        // Enfin, on lance l'intent pour que l'application de photo se lance
        startActivityForResult(intent, 1337);


    }






    // My private attribute which is the location listener
    private LocationListener locationListener = new LocationListener() {
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }

        @Override
        public void onLocationChanged(Location location) {
            lastLocation = location;
            lastTime = new Time(location.getTime());
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.FRANCE);
            if (isMapReady) {
                // Add a marker and move the camera
                LatLng position = new LatLng(lastLocation.getLatitude(), lastLocation.getLongitude());
                latitude=lastLocation.getLatitude();
                longitude=lastLocation.getLongitude();
                if (mMarker == null) {
                    mMarker = mMap.addMarker(new MarkerOptions().position(new LatLng(0,0)));
                }
                mMarker.setPosition(position);
                mMarker.setTitle(sdf.format(lastTime));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(position, 17));
            }
            Toast.makeText(GeoActivity.this, "Position mise à jour...", Toast.LENGTH_LONG).show();
            // One position is knew, the user can click on the picture button
            bouton_photo.setEnabled(true);
        }
    };

    public void mapUpdate(){
        if(isMapReady) {
            List<Localisation> liste = mLocalisationDataAccessObject.readAll();
            for (int i = 0; i < liste.size(); i++) {
                Localisation obj = liste.get(i);
                String chemin_image = obj.get_image();
                Bitmap resized = ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(chemin_image), 100, 100);
                Matrix mx = new Matrix();
                mx.postRotate(90);
                resized = Bitmap.createBitmap(resized, 0,0, resized.getWidth(),resized.getHeight(), mx, true);
                double lat = obj.getLatitude();
                double longi = obj.getLongitude();
                mMap.addMarker(new MarkerOptions().position(new LatLng(lat, longi)).icon(BitmapDescriptorFactory.fromBitmap(resized)));
            }

        }
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1337 && resultCode == RESULT_OK) {
            //result.setText("1");

            if (data != null) {
                Uri selectedImageURI = data.getData();
                mCurrentPhotoPath = getRealPathFromURI(selectedImageURI);
            }
        }
        }





    private String getRealPathFromURI(Uri contentURI)
    {
        String result = null;

        Cursor cursor = getContentResolver().query(contentURI, null, null, null, null);

        if (cursor == null)
        { // Source is Dropbox or other similar local file path
            result = contentURI.getPath();
        }
        else
        {
            if(cursor.moveToFirst())
            {
                int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                result = cursor.getString(idx);
            }
            cursor.close();
        }
        return result;
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        isMapReady = true;
    }
}
